import React, {useEffect, useState} from 'react';
import {SafeAreaView, View, Text, TextInput, ScrollView, Pressable, StyleSheet, StatusBar} from 'react-native';
import {createClient} from '@supabase/supabase-js';
const url=process.env.EXPO_PUBLIC_SUPABASE_URL, key=process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
const supabase=url&&key?createClient(url,key):null;
const demo=[
 {id:'1',title:'Toyota Camry 2.5',year:2019,price:1850000,city:'Сухум',mileage_km:78000},
 {id:'2',title:'Mercedes-Benz E-Class',year:2017,price:2350000,city:'Гагра',mileage_km:96000},
 {id:'3',title:'BMW 3 Series',year:2020,price:2700000,city:'Гудаута',mileage_km:54000},
 {id:'4',title:'Hyundai Tucson',year:2021,price:2500000,city:'Новый Афон',mileage_km:43000}
];
const fmt=n=>new Intl.NumberFormat('ru-RU').format(n||0);
export default function App(){
 const [cars,setCars]=useState(demo),[query,setQuery]=useState('');
 useEffect(()=>{if(supabase)supabase.from('listings').select('id,title,year,price,city,mileage_km').eq('status','published').order('created_at',{ascending:false}).then(({data,error})=>{if(!error&&data)setCars(data)});},[]);
 const visible=cars.filter(c=>c.title.toLowerCase().includes(query.toLowerCase()));
 return <SafeAreaView style={s.safe}><StatusBar barStyle="light-content"/><ScrollView contentContainerStyle={s.page}>
  <View style={s.header}><Text style={s.brand}>APSNY <Text style={{color:'#ff4d40'}}>AVTO</Text></Text><Text style={s.sub}>АВТОМОБИЛИ АБХАЗИИ</Text></View>
  <Text style={s.kicker}>АВТОРЫНОК АБХАЗИИ</Text><Text style={s.hero}>Твоя следующая<Text style={{color:'#ff4d40'}}> дорога</Text>{'\\n'}начинается здесь.</Text>
  <Text style={s.desc}>Покупай и продавай автомобили по всей Абхазии.</Text>
  <TextInput value={query} onChangeText={setQuery} placeholder="Марка или модель" placeholderTextColor="#888" style={s.search}/>
  <View style={s.row}><Text style={s.heading}>В продаже</Text><Text style={s.count}>{visible.length} объявлений</Text></View>
  {visible.map((c,i)=><View key={c.id} style={s.card}><View style={[s.art,{backgroundColor:['#352421','#202b30','#342a21','#233027'][i%4]}]}><Text style={s.artText}>APSNY AVTO</Text></View><View style={s.cardBody}><Text style={s.title}>{c.title}</Text><Text style={s.meta}>{c.year}  ·  {fmt(c.mileage_km)} км  ·  {c.city}</Text><Text style={s.price}>{fmt(c.price)} <Text style={s.currency}>RUB</Text></Text></View></View>)}
  <Pressable style={s.button} onPress={()=>{}}><Text style={s.buttonText}>Разместить авто</Text></Pressable><Text style={s.note}>Стартовая версия. Для публикации объявлений подключите авторизацию, загрузку фотографий и модерацию.</Text>
 </ScrollView></SafeAreaView>
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:'#101214'},page:{padding:20,paddingBottom:45},header:{paddingVertical:12,marginBottom:34,borderBottomWidth:1,borderBottomColor:'#303334'},brand:{fontSize:23,fontWeight:'900',color:'#fff',letterSpacing:1},sub:{fontSize:9,color:'#929696',letterSpacing:2,marginTop:5},kicker:{fontSize:10,color:'#ff4d40',letterSpacing:2,fontWeight:'800'},hero:{fontSize:38,fontWeight:'900',color:'#f6f6f3',lineHeight:45,marginTop:18},desc:{fontSize:14,color:'#a5aaaa',lineHeight:22,marginTop:14,marginBottom:20},search:{backgroundColor:'#1b1e20',borderWidth:1,borderColor:'#333738',borderRadius:8,padding:14,color:'#fff',marginBottom:28},row:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginBottom:15},heading:{fontSize:25,fontWeight:'800',color:'#fff'},count:{fontSize:11,color:'#929696'},card:{backgroundColor:'#1a1d1f',borderWidth:1,borderColor:'#303334',borderRadius:10,overflow:'hidden',marginBottom:14},art:{height:145,alignItems:'center',justifyContent:'center'},artText:{color:'#ffffff55',fontSize:17,fontWeight:'900',letterSpacing:4},cardBody:{padding:15},title:{fontSize:16,fontWeight:'800',color:'#f4f4f1'},meta:{fontSize:11,color:'#a2a6a6',marginTop:9},price:{fontSize:22,fontWeight:'900',color:'#fff',marginTop:13},currency:{fontSize:11,color:'#a2a6a6',fontWeight:'500'},button:{backgroundColor:'#ff4d40',borderRadius:8,padding:16,alignItems:'center',marginTop:10},buttonText:{color:'#fff',fontWeight:'800'},note:{fontSize:11,lineHeight:18,color:'#929696',marginTop:18}});
