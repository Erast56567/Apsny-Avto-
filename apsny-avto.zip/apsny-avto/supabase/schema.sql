-- Apsny Avto starter schema for Supabase/Postgres
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  phone text,
  city text not null default 'Сухум',
  created_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 4 and 100),
  make text not null,
  model text not null,
  year int not null check (year between 1950 and 2100),
  price numeric(12,2) not null check (price >= 0),
  currency text not null default 'RUB' check (currency in ('RUB','USD','EUR','KGS','GEL')),
  mileage_km int check (mileage_km is null or mileage_km >= 0),
  city text not null,
  description text,
  photo_urls text[] not null default '{}',
  phone text,
  status text not null default 'pending' check (status in ('pending','published','rejected','sold')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists listings_status_city_created_idx
  on public.listings(status, city, created_at desc);
create index if not exists listings_price_idx on public.listings(price);
create index if not exists listings_make_model_idx on public.listings(make, model);

alter table public.profiles enable row level security;
alter table public.listings enable row level security;

create policy "profiles readable by signed-in users"
on public.profiles for select to authenticated using (true);
create policy "users insert own profile"
on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "users update own profile"
on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "published listings are public"
on public.listings for select to anon, authenticated using (status = 'published' or auth.uid() = seller_id);
create policy "signed-in users create own pending listings"
on public.listings for insert to authenticated with check (auth.uid() = seller_id and status = 'pending');
create policy "sellers update own listings"
on public.listings for update to authenticated using (auth.uid() = seller_id) with check (auth.uid() = seller_id);
create policy "sellers delete own listings"
on public.listings for delete to authenticated using (auth.uid() = seller_id);

-- Do not allow ordinary users to set status='published'. For a real launch,
-- remove broad seller update access and replace with column-restricted updates
-- or route moderation through a trusted server/Edge Function.
-- Create a Storage bucket named car-photos in the Supabase dashboard and add
-- policies restricting upload/delete to authenticated users and their own folder.
